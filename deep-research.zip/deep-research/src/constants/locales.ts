export default {
  "en-US": "English",
  "zh-CN": "简体中文",
} as const;
